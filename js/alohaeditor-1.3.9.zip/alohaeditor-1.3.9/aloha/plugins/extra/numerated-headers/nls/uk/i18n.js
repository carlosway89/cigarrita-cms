define({
	"headerids.label.target": "Ціль",
	"headerids.button.reset": "Скинути",
	"headerids.button.set": "Встановити"
});
