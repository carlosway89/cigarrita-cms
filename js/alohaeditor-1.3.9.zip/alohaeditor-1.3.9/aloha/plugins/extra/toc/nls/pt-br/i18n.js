define({
	"button.addtoc.tooltip": "Tabela de conteúdo"
});
