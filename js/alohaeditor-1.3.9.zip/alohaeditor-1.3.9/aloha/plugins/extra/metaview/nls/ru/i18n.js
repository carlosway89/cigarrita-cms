define({
	"button.switch-metaview.tooltip": "Переключение между мета- и нормальным видом"
});
