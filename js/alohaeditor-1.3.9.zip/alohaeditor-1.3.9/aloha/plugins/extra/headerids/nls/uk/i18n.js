define({
	"headerids.label.target": "Ціль",
	"headerids.button.reset": "Скинути",
	"headerids.button.set": "Встановити",
	"internal_hyperlink": "Внутрішнє посилання"
});
