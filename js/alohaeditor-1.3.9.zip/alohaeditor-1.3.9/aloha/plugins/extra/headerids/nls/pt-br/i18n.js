define({
	"headerids.label.target": "Alvo",
	"headerids.button.reset": "Resetar",
	"headerids.button.set": "Definir",
	"internal_hyperlink": "Hyperlink interno"
});
