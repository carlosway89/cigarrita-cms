define({
	root: {
		'change-textcolor-color': 'Change text color',
		'remove-textcolor-color': 'Remove text color',
		'change-textcolor-background-color': 'Change text background-color',
		'remove-textcolor-background-color': 'Remove text background-color'
	},
	de: true
});
