define({
	"floatingmenu.tab.wai-lang": "Мовна анотація",
	"button.add-wai-lang-remove.tooltip": "Видалити мовну анотацію",
	"button.add-wai-lang.tooltip": "Додати мовну анотацію"
});
