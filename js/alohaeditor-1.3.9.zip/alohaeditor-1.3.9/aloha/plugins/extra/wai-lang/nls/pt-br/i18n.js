define({
	"floatingmenu.tab.wai-lang": "Anotação de linguagem",
	"button.add-wai-lang-remove.tooltip": "Remover anotação de linguagem",
	"button.add-wai-lang.tooltip": "Adicionar anotação de linguagem"
});
