define({
	"floatingmenu.tab.wai-lang": "Јазична анотација",
	"button.add-wai-lang-remove.tooltip": "Одстрани јазична анотација",
	"button.add-wai-lang.tooltip": "Додади јазична анотација"
});
