define({
	"floatingmenu.tab.wai-lang": "语言注释",
	"button.add-wai-lang-remove.tooltip": "移除语言注释",
	"button.add-wai-lang.tooltip": "添加语言注释"
});
