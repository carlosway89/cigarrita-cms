define({
	"floatingmenu.tab.file": "文件"
});
