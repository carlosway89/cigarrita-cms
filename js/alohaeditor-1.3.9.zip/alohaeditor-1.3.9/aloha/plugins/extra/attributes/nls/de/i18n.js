define({
	"headerids.label.target": "Ziel",
	"headerids.button.reset": "Zurücksetzen",
	"headerids.button.set": "Setzen"
});
