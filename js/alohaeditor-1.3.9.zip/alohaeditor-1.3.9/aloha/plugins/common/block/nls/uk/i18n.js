define({
	"button.toggledragdrop.tooltip": "Перемикач Drag & Drop"
});
