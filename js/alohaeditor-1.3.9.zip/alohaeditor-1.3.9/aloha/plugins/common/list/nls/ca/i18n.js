define({
	"button.createulist.tooltip": "Insereix una llista sense ordre",
	"button.createolist.tooltip": "Insereix una llista amb ordre",
	"button.indentlist.tooltip": "Sagna la llista",
	"button.outdentlist.tooltip": "Desfés el sagnat de la llista",
	"floatingmenu.tab.list": "Llistes"
});
