define({
	"button.addhr.tooltip": "Afegeix un regle horitzontal"
});
