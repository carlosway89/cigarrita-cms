define({
	"button.addhr.tooltip": "Додати горизонтальну лінійку"
});
