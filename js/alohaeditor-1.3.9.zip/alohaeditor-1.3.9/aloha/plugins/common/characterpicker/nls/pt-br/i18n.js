define({
	"button.addcharacter.tooltip": "Escolher caracteres especiais"
});
