define({
	"floatingmenu.tab.abbr": "缩写",
	"button.addabbr.tooltip": "插入缩写",
	"button.abbr.tooltip": "格式化为缩写",
	"newabbr.defaulttext": "缩写文字"
});
