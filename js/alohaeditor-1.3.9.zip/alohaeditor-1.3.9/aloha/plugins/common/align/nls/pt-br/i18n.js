define({
	"button.alignright.tooltip": "Alinhar a direita",
	"button.alignleft.tooltip": "Alinhar a esquerda",
	"button.aligncenter.tooltip": "Centro",
	"button.alignjustify.tooltip": "Justificar"
});
